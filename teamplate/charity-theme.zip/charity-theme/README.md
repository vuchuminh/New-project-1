## This project was created for this blog post: 
## https://medium.com/@shuvohabib/learn-css-bem-methodology-by-two-complete-free-template-c0f531f49cdb

# Open Charity

- BEM methodology. 
- SCSS. 
- Theme is tested on latest browsers like, Chrome, Firefox, Safari, Edge and with IE11.
- Owl Carousel.
